import "../components/Home.css";
function Home() {
  return (
    <>
      <div class="hero bg-img-dish">
        <div class="hero_content">
          <h1>Bite Bliss</h1>
          <h2>A taste of India Without Border</h2>
          <a href="/menu">Menu</a>
        </div>
      </div>
    </>
  );
}

export default Home;

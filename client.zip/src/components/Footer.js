import "../components/Footer.css";
function Footer() {
  return (
    <>

    </>
  );
}

export default Footer;

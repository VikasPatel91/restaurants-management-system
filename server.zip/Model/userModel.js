import mongoose from "mongoose";

const mongoSchema = mongoose.Schema({
  name: {
    type: String,
    require: true,
  },
  email: {
    type: String,
    require: true,
  },
  // phone: {
  //   type: String,
  //   require: true,
  // },
  password: {
    type: String,
    require: true,
  },
});
const userModel = mongoose.model("my", mongoSchema);
export default userModel;

import mongoose from "mongoose";

const mongoSchema = mongoose.Schema({
  dish: {
    type: String,
    require: true,
  },
  imageUrl: {
    type: String,
    require: true,
  },
  recipe: {
    type: String,
    require: true,
  },
  price: {
    type: String,
    require: true,
  },
});
const diesModel = mongoose.model("User", mongoSchema);
export default diesModel;

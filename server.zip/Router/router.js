import express from "express";
import {
  InsertDish,
  dishData,
  dishUpdate,
  dishDelete,
  dishAllDelete,
} from "../Controller/dishController.js";
import { InsertUser, login, userData, userUpdate } from "../Controller/userController.js";

const router = express.Router();

router.get("/", (req, res) => {
  res.send("welcome to home page");
});
router.post("/in-dish", InsertDish);
router.get("/out-dish", dishData);
router.put("/update-dish/:id", dishUpdate);
router.delete("/dish/:id", dishDelete);
router.delete("/delete-all-dish", dishAllDelete);

router.post("/user", InsertUser);
router.get("/users", userData);
router.post("/login", login);
router.put("user/:id",userUpdate)
export default router;

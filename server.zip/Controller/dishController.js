import model from "../Model/dishModel.js";
export async function InsertDish(req, res) {
  try {
    const user = await model(req.body);
    const saved = await user.save();
    res.json(saved).status(201);
  } catch (error) {
    res.json(error).status(400);
  }
}

export async function dishData(req, res) {
  const user = await model.find();
  res.json(user).status(200);
}

export async function dishUpdate(req, res) {
  const id = req.params.id;
  const user = await model.findByIdAndUpdate({ id: id });
  res.json(user).status(200);
}

export async function dishDelete(req, res) {
  const user = await model.findByIdAndDelete(req.param.id);
  res.json(user).status(200);
}

export async function dishAllDelete(req, res) {
    const user = await model.deleteMany();
  res.json(user).status(200);
}
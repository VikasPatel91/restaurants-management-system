import model from "../Model/userModel.js";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
export async function InsertUser(req, res) {
  try {
    const user = await model({
      name: req.body.name,
      email: req.body.email,
      //   phone: req.body.phone,
      password: await bcrypt.hash(req.body.password, 12),
    });
    const saved = await user.save();
    res.json(saved).status(201);
  } catch (error) {
    res.json(error).status(400);
  }
}

export async function userData(req, res) {
  const user = await model.find();
  res.json(user).status(200);
}

export async function login(req, res) {
  const userEmail = await model.findOne({
    email: req.body.email,
  });
  if (userEmail) {
    if (bcrypt.compareSync(req.body.password, userEmail.password)) {
      const token = jwt.sign({ loginUserId: userEmail._id }, "24680");
      res.status(200).json(`login success, token :${token}`);
    } else {
      res.status(400);
      res.json("Password is incorrect");
    }
  } else {
    res.status(400);
    res.json("invalid email id");
  }
}
export async function userUpdate(req, res) {
  const id = req.params.id;
  const user = await model.findByIdAndUpdate({ id: id });
  res.json(user).status(200);
}
